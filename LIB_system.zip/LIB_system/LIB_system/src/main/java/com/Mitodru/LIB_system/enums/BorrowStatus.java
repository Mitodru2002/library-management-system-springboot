package com.Mitodru.LIB_system.enums;


public enum BorrowStatus {
    BORROWED,
    RETURNED,
    OVERDUE,
    LOST
}
