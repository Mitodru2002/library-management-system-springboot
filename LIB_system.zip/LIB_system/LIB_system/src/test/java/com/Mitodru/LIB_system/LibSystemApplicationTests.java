package com.Mitodru.LIB_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
